/**
 * PM2 进程管理配置文件
 * 用法: pm2 start ecosystem.config.cjs
 */
module.exports = {
  apps: [{
    name: 'sharkfit',
    script: './server.js',
    cwd: '/www/wwwroot/fitness-pwa/server',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '256M',
    env: {
      NODE_ENV: 'production',
      PORT: 3001,
    },
    // 日志配置
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    error_file: '/www/wwwroot/fitness-pwa/logs/error.log',
    out_file: '/www/wwwroot/fitness-pwa/logs/out.log',
    merge_logs: true,
  }],
};
